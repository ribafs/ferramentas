<?php

namespace Doctrine\ActiveRecord\Exception;

class ModelException extends Exception {
}