<?php

namespace Doctrine\ActiveRecord\Exception;

class Exception extends \Exception {
}