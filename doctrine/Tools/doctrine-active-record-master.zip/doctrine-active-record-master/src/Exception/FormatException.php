<?php

namespace Doctrine\ActiveRecord\Exception;

class FormatException extends Exception {
}