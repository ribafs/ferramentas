<?php

namespace Doctrine\ActiveRecord\Exception;

class NotFoundException extends Exception {
}