<?php

namespace Doctrine\ActiveRecord\Exception;

class UpdateException extends ModelException {
}