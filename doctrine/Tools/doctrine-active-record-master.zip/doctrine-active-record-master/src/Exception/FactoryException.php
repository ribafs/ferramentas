<?php

namespace Doctrine\ActiveRecord\Exception;

class FactoryException extends Exception {
}