<?php

namespace Doctrine\ActiveRecord\Exception;

class InvalidFormException extends ModelException {
}