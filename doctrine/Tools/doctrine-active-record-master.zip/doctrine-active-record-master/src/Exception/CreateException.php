<?php

namespace Doctrine\ActiveRecord\Exception;

class CreateException extends ModelException {
}