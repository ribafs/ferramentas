<?php

namespace Doctrine\ActiveRecord\Exception;

class DeleteException extends ModelException {
}