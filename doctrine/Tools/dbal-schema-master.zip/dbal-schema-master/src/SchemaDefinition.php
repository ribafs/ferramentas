<?php declare(strict_types = 1);

namespace DbalSchema;

use Doctrine\DBAL\Schema\Schema;

interface SchemaDefinition
{
    /**
     * Define a schema by configuring the provided Schema instance.
     *
     * @return void
     */
    public function define(Schema $schema);
}
