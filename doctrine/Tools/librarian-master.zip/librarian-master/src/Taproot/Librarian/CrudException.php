<?php

namespace Taproot\Librarian;

class CrudException extends \Exception {
	
}