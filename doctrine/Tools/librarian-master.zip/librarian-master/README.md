librarian
=========

An event-driven flat file CRUD system with Doctrine DBAL based indexes
