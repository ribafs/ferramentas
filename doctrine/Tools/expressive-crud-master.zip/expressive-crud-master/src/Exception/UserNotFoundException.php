<?php

namespace App\Exception;

class UserNotFoundException extends EntityNotFoundException
{
}

