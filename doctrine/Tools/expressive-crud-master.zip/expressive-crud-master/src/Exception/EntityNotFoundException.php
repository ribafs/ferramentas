<?php

namespace App\Exception;

class EntityNotFoundException extends \RuntimeException
    implements ExceptionInterface
{
}

