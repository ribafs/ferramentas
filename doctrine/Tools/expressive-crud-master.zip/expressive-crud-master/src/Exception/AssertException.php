<?php

namespace App\Exception;

class AssertExceptoin extends \InvalidArgumentException
    implements ExceptionInterface
{
}

