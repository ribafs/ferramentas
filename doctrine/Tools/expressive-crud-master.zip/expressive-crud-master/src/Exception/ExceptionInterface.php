<?php

namespace App\Exception;

interface ExceptionInterface
{
}

