<?php

namespace App\Exception;

class EntityIdAlreadySetException extends \BadMethodCallException
    implements ExceptionInterface
{
}

