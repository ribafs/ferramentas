<?php

namespace App\Mapper;

use App\Mapper\EntityMapperInterface;

interface UserMapperInterface extends EntityMapperInterface
{
}

