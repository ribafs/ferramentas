<?php

namespace App\Model;

use ActiveRecord\Model;

class Pessoa extends Model
{
    static $table_name = 'pessoa';
}